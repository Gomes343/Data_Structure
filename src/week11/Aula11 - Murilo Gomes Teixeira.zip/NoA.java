package week11;

import week10.*;

public class NoA {
    int valor;
    NoA dir;
    NoA esq;
    
    NoA(int v){
        this.valor = v;
        this.dir = null;
        this.esq = null;
    }
    
}